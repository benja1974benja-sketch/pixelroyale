# PixelRoyale actualizado

## Incluye
- Lobby y cuenta atrás.
- Solo / escuadrones de 2, 3 y 4.
- Equipos y fuego amigo desactivado.
- Battle Royale: último jugador/equipo vivo gana.
- Tormenta progresiva.
- Loot: armas, escudo, botiquín, munición y materiales.
- 5 armas: pistola, subfusil, escopeta, rifle y francotirador.
- Construcciones: pared, rampa, suelo y techo (selección automática por ciclo).
- XP, monedas, eliminaciones y pantalla de recompensas.
- Botón JUGAR OTRA VEZ.

## Render
Build command: `npm install`
Start command: `npm start`
Node 18+
