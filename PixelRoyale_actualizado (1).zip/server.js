const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = process.env.PORT || 3000;
const WORLD = 2400;
const MAX_PLAYERS = 32;
const MIN_START = 2;
const BUILD_COST = 10;
const server = http.createServer((req,res)=>{
  if(req.url==='/'||req.url==='/index.html'){
    fs.readFile(path.join(__dirname,'client.html'),(err,data)=>{if(err){res.writeHead(500);return res.end('Error cargando el juego')}res.writeHead(200,{'Content-Type':'text/html'});res.end(data)});
  } else {res.writeHead(404);res.end('Not found');}
});
const wss=new WebSocket.Server({server});
const players=new Map(), walls=[], trees=[], loot=[];
let nextId=1,nextWallId=1,nextTreeId=1,nextLootId=1;
const weapons={pistol:{name:'Pistola',damage:24,rate:260,ammo:12,maxAmmo:12,range:650},smg:{name:'Subfusil',damage:14,rate:90,ammo:30,maxAmmo:30,range:600},shotgun:{name:'Escopeta',damage:11,rate:650,ammo:6,maxAmmo:6,range:350,pellets:7},rifle:{name:'Rifle',damage:31,rate:170,ammo:20,maxAmmo:20,range:850},sniper:{name:'Francotirador',damage:90,rate:1000,ammo:5,maxAmmo:5,range:1200}};
let storm={cx:WORLD/2,cy:WORLD/2,radius:WORLD*.66,target:WORLD*.66,stage:0,nextAt:Date.now()+30000,damage:2};
let phase='lobby',countdown=10,matchStartedAt=0,gameNumber=1,matchTeamSize=1;
function rand(a,b){return Math.random()*(b-a)+a} function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y)} function teamOf(p){return p.team||p.id}
function broadcast(data,except=null){const s=JSON.stringify(data);for(const [id,p] of players)if(id!==except&&p.ws.readyState===WebSocket.OPEN)p.ws.send(s)}
function broadcastAll(data){broadcast(data)}
function snapshot(p){return {id:p.id,x:p.x,y:p.y,angle:p.angle,health:p.health,shield:p.shield,materials:p.materials,color:p.color,name:p.name,emote:p.emote,alive:p.alive,slot:p.slot,weapon:p.weapon,ammo:p.ammo,maxAmmo:p.maxAmmo,team:p.team,teamMode:p.teamMode,kills:p.kills,xp:p.xp}}
function spawnPoint(){return {x:250+Math.random()*(WORLD-500),y:250+Math.random()*(WORLD-500)}}
for(let i=0;i<70;i++)trees.push({id:nextTreeId++,x:100+Math.random()*(WORLD-200),y:100+Math.random()*(WORLD-200),health:80,maxHealth:80,radius:18});
function makeLoot(x,y,type,rarity){const id=nextLootId++;loot.push({id,x,y,type,rarity});return loot[loot.length-1]}
function spawnLoot(){loot.length=0;const types=['weapon','shield','medkit','ammo','materials'];const rares=['common','uncommon','rare','epic','legendary'];for(let i=0;i<65;i++){const s=spawnPoint();const type=types[Math.floor(Math.random()*types.length)];let item=type;if(type==='weapon'){const ws=['pistol','smg','shotgun','rifle','sniper'];item=ws[Math.floor(Math.random()*ws.length)]}makeLoot(s.x,s.y,item,rares[Math.floor(Math.random()*rares.length)])}}
function resetPlayer(p){const s=spawnPoint();p.x=s.x;p.y=s.y;p.health=100;p.shield=0;p.materials=30;p.alive=true;p.kills=0;p.xp=0;p.weapon='pistol';p.ammo=12;p.maxAmmo=12;p.slot=2;p.eliminatedBy=null}
function assignTeams(){const arr=[...players.values()].sort(()=>Math.random()-.5);matchTeamSize=Math.max(1,Math.min(4,Number(arr[0]?.teamMode)||1));let team=1;for(let i=0;i<arr.length;i++){arr[i].team=Math.ceil((i+1)/matchTeamSize);arr[i].teamMode=matchTeamSize}}
function startMatch(){if(players.size<MIN_START)return;phase='playing';matchStartedAt=Date.now();storm={cx:WORLD/2,cy:WORLD/2,radius:WORLD*.66,target:WORLD*.66,stage:0,nextAt:Date.now()+35000,damage:2};assignTeams();spawnLoot();for(const p of players.values())resetPlayer(p);broadcastAll({type:'matchStart',players:[...players.values()].map(snapshot),loot,storm,gameNumber,teamMode:matchTeamSize});}
function checkStart(){if(phase==='lobby'&&players.size>=MIN_START){phase='countdown';countdown=10;broadcastAll({type:'countdown',value:countdown});setTimeout(()=>{if(phase==='countdown')startMatch()},10000)}}
function endMatch(winnerTeam=null){phase='gameover';const alive=[...players.values()].filter(p=>p.alive);let winningTeam=winnerTeam;if(!winningTeam&&alive.length)winningTeam=alive[0].team;for(const p of players.values()){const placement=p.alive?1:2;const xp=placement===1?800:250+p.kills*100;p.xp+=xp;p.coins=(p.coins||0)+(placement===1?500:100+p.kills*25)}broadcastAll({type:'matchEnd',winnerTeam,players:[...players.values()].map(snapshot),rewards:[...players.values()].map(p=>({id:p.id,xp:p.xp,coins:p.coins||0,kills:p.kills,alive:p.alive}))});}
function eliminate(p,killerId){if(!p.alive)return;p.alive=false;p.health=0;p.eliminatedBy=killerId;const killer=players.get(killerId);if(killer&&killer!==p){killer.kills++;killer.materials+=15;killer.xp=(killer.xp||0)+100}broadcastAll({type:'playerDied',id:p.id,killerId,kills:killer?killer.kills:0});const alive=[...players.values()].filter(x=>x.alive);const teams=new Set(alive.map(teamOf));if(alive.length<=1||teams.size<=1)endMatch(alive[0]?.team||winnerTeamOf(p));}
function winnerTeamOf(p){return p.team}
function damagePlayer(attacker,target,dmg){if(!target||!target.alive)return;if(target.team===attacker.team&&target.teamMode>1)return;if(target.shield>0){const a=Math.min(target.shield,dmg);target.shield-=a;dmg-=a}if(dmg>0)target.health-=dmg;if(target.health<=0)eliminate(target,attacker.id);else broadcastAll({type:'playerDamaged',id:target.id,health:target.health,shield:target.shield});}
function inStorm(p){return dist(p,{x:storm.cx,y:storm.cy})>storm.radius}
setInterval(()=>{
 if(phase==='countdown'){countdown--;broadcastAll({type:'countdown',value:countdown});if(countdown<=0&&players.size>=MIN_START)startMatch()}
 if(phase==='playing'){
  if(Date.now()>storm.nextAt&&storm.target>180){storm.stage++;storm.target=Math.max(180,storm.target*.72);storm.nextAt=Date.now()+25000;storm.damage=Math.min(12,2+storm.stage*2);broadcastAll({type:'stormUpdate',storm});}
  storm.radius+=(storm.target-storm.radius)*.008;
  for(const p of players.values())if(p.alive&&inStorm(p)){p.health-=storm.damage*.2;if(p.health<=0)eliminate(p,null);else broadcastAll({type:'playerDamaged',id:p.id,health:p.health,shield:p.shield});}
  broadcastAll({type:'stormTick',storm});
 }
},1000);
wss.on('connection',ws=>{
 if(players.size>=MAX_PLAYERS){ws.send(JSON.stringify({type:'full'}));return ws.close()}
 const id=nextId++,s=spawnPoint();const p={id,ws,x:s.x,y:s.y,angle:0,health:100,shield:0,materials:30,color:`hsl(${Math.random()*360},70%,55%)`,name:`Jugador ${id}`,emote:null,alive:true,kills:0,slot:2,weapon:'pistol',ammo:12,maxAmmo:12,team:id,teamMode:1,xp:0,coins:0};players.set(id,p);
 ws.send(JSON.stringify({type:'welcome',id,phase,players:[...players.values()].map(snapshot),walls,trees,loot,storm,gameNumber,teamMode:1}));
 broadcast({type:'playerJoined',player:snapshot(p)},id);checkStart();
 ws.on('message',raw=>{let d;try{d=JSON.parse(raw)}catch{return}const me=players.get(id);if(!me)return;
  if(d.type==='setName'){me.name=(d.name||`Jugador ${id}`).slice(0,16);broadcastAll({type:'nameChange',id,name:me.name});return}
  if(d.type==='setTeamMode'){const n=Math.min(4,Math.max(1,Number(d.mode)||1));me.teamMode=n;broadcastAll({type:'teamMode',mode:n});return}
  if(d.type==='joinTeam'){const t=Math.max(1,Number(d.team)||1);const members=[...players.values()].filter(x=>x.team===t);if(members.length<me.teamMode){me.team=t;broadcastAll({type:'teamChanged',id,team:t})}return}
  if(d.type==='chat'){broadcastAll({type:'chat',id,name:me.name,message:(d.message||'').slice(0,100)});return}
  if(phase!=='playing'||!me.alive)return;
  switch(d.type){
   case 'update':me.x=Math.max(20,Math.min(WORLD-20,Number(d.x)||me.x));me.y=Math.max(20,Math.min(WORLD-20,Number(d.y)||me.y));me.angle=Number(d.angle)||0;me.emote=d.emote||null;me.slot=d.slot||me.slot;broadcast({type:'playerUpdate',...snapshot(me)},id);break;
   case 'shoot':{const w=weapons[me.weapon]||weapons.pistol;if(me.slot!==2)break;if(me.ammo<=0){ws.send(JSON.stringify({type:'reloadNeeded'}));break}me.ammo--;broadcastAll({type:'shoot',id,x:me.x,y:me.y,angle:me.angle,weapon:me.weapon});let targets=[...players.values()].filter(t=>t.alive&&t.id!==id&&t.team!==me.team&&dist(me,t)<w.range);targets.sort((a,b)=>dist(me,a)-dist(me,b));if(targets[0]){let dmg=w.damage;if(me.weapon==='shotgun')dmg*=w.pellets;damagePlayer(me,targets[0],dmg)}break}
   case 'reload':{const w=weapons[me.weapon]||weapons.pistol;me.ammo=me.maxAmmo||w.maxAmmo;ws.send(JSON.stringify({type:'reloaded',ammo:me.ammo,maxAmmo:me.maxAmmo}));break}
   case 'selectWeapon':if(weapons[d.weapon]){me.weapon=d.weapon;me.maxAmmo=weapons[d.weapon].maxAmmo;me.ammo=Math.min(me.ammo||me.maxAmmo,me.maxAmmo);ws.send(JSON.stringify({type:'weaponChanged',weapon:me.weapon,ammo:me.ammo,maxAmmo:me.maxAmmo}))}break;
   case 'hit':{const t=players.get(d.targetId);if(t)damagePlayer(me,t,Math.max(1,Number(d.damage)||20));break}
   case 'build':if(me.materials>=BUILD_COST){const kind=['wall','ramp','floor','roof'].includes(d.kind)?d.kind:'wall';me.materials-=BUILD_COST;const wall={id:nextWallId++,x:Number(d.x)||me.x,y:Number(d.y)||me.y,w:kind==='ramp'?60:40,h:40,health:kind==='wall'?160:120,ownerId:id,kind};walls.push(wall);broadcastAll({type:'wallBuilt',wall,materials:me.materials,playerId:id});}break;
   case 'wallHit':{const w=walls.find(x=>x.id===d.wallId);if(w){w.health-=Number(d.damage)||25;if(w.health<=0){walls.splice(walls.indexOf(w),1);broadcastAll({type:'wallDestroyed',wallId:w.id})}else broadcastAll({type:'wallDamaged',wallId:w.id,health:w.health})}break}
   case 'treeHit':{const t=trees.find(x=>x.id===d.treeId);if(t&&me.slot===1){t.health-=25;if(t.health<=0){trees.splice(trees.indexOf(t),1);me.materials+=20+Math.floor(Math.random()*15);broadcastAll({type:'treeDestroyed',treeId:t.id,playerId:id,materials:me.materials})}else broadcastAll({type:'treeDamaged',treeId:t.id,health:t.health})}break}
   case 'pickup':{const item=loot.find(x=>x.id===d.lootId);if(!item||dist(me,item)>70)break;loot.splice(loot.indexOf(item),1);if(item.type==='shield'){me.shield=Math.min(100,me.shield+50)}else if(item.type==='medkit'){me.health=Math.min(100,me.health+50)}else if(item.type==='ammo'){me.ammo=me.maxAmmo}else if(item.type==='materials'){me.materials+=40}else if(weapons[item.type]){me.weapon=item.type;me.maxAmmo=weapons[item.type].maxAmmo;me.ammo=me.maxAmmo}broadcastAll({type:'lootPicked',lootId:item.id,playerId:id,item});break}
  }
 });
 ws.on('close',()=>{players.delete(id);broadcastAll({type:'playerLeft',id});if(players.size<MIN_START)phase='lobby'});
});
server.listen(PORT,'0.0.0.0',()=>console.log(`PixelRoyale server on ${PORT}`));
